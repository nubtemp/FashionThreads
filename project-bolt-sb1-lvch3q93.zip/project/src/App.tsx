import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Description from './components/Description';
import StylePreview from './components/StylePreview';
import Testimonial from './components/Testimonial';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import ProductsPage from './components/ProductsPage';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'products'>('home');

  const navigateToProducts = () => {
    setCurrentPage('products');
  };

  const navigateToHome = () => {
    setCurrentPage('home');
  };

  if (currentPage === 'products') {
    return <ProductsPage onBack={navigateToHome} />;
  }

  return (
    <div className="min-h-screen">
      <Header onStylesClick={navigateToProducts} />
      <Hero onShopClick={navigateToProducts} />
      <Description />
      <StylePreview onViewClick={navigateToProducts} />
      <Testimonial />
      <FinalCTA onDiscoverClick={navigateToProducts} />
      <Footer />
    </div>
  );
}

export default App;