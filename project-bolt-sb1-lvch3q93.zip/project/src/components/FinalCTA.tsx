import React from 'react';
import { ArrowRight } from 'lucide-react';

interface FinalCTAProps {
  onDiscoverClick: () => void;
}

const FinalCTA: React.FC<FinalCTAProps> = ({ onDiscoverClick }) => {
  return (
    <section className="bg-gradient-to-r from-pink-200 via-rose-200 to-pink-200 py-24 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-5xl lg:text-6xl font-bold text-gray-800 mb-6 font-playfair">
          Elevate Your Style Game
        </h2>
        <p className="text-xl text-gray-700 mb-10 leading-relaxed max-w-2xl mx-auto">
          Discover the latest fashion trends for your unique and sophisticated collections that bring 
          great style to elegant looks. Step out in style with FashionThreads.
        </p>
        <button 
          onClick={onDiscoverClick}
          className="bg-pink-500 hover:bg-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl flex items-center space-x-2 mx-auto"
        >
          <span>Discover Trends</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </section>
  );
};

export default FinalCTA