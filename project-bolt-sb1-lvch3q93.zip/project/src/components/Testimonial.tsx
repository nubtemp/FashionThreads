import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonial = () => {
  return (
    <section className="bg-white py-20 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <Quote className="w-12 h-12 text-pink-300 mx-auto mb-6" />
        <blockquote className="text-2xl lg:text-3xl text-gray-700 font-light mb-8 leading-relaxed font-playfair">
          "FashionThreads offers an impressive selection of trendy pieces. Their clothing is consistently stylish and of great quality, making it easy for me to find something I love every time I visit. Highly recommend for any fashion enthusiast!"
        </blockquote>
        <div className="flex justify-center mb-4">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-6 h-6 text-pink-400 fill-current" />
          ))}
        </div>
        <cite className="text-gray-600 font-medium">- Olivia Stuart</cite>
      </div>
    </section>
  );
};

export default Testimonial;