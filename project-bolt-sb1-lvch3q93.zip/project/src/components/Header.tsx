import React from 'react';
import { Sparkles } from 'lucide-react';

interface HeaderProps {
  onStylesClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onStylesClick }) => {
  return (
    <header className="bg-gradient-to-r from-pink-50 to-rose-50 py-4 px-6 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-8 h-8 text-pink-400" />
          <h1 className="text-2xl font-bold text-gray-800 font-playfair">FashionThreads</h1>
        </div>
        <nav className="hidden md:flex space-x-8">
          <a href="#" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">Home</a>
          <button 
            onClick={onStylesClick}
            className="text-gray-700 hover:text-pink-500 transition-colors font-medium"
          >
            Styles
          </button>
          <a href="#" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">About</a>
          <a href="#" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">Contact</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;