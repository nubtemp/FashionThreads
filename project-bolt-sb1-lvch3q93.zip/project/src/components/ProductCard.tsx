import React from 'react';
import { ExternalLink, Heart } from 'lucide-react';

interface ProductCardProps {
  id: string;
  image: string;
  title: string;
  description: string;
  links: Array<{
    name: string;
    url: string;
    price?: string;
  }>;
}

const ProductCard: React.FC<ProductCardProps> = ({ image, title, description, links }) => {
  return (
    <div className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden group">
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="w-full h-96 object-contain bg-gray-50 transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <button className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-pink-50">
          <Heart className="w-5 h-5 text-pink-400 hover:fill-current transition-colors" />
        </button>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-3 font-playfair">{title}</h3>
        <p className="text-gray-600 mb-4 leading-relaxed text-sm">{description}</p>
        
        <div className="space-y-2">
          {links.map((link, index) => (
            <a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3 bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl hover:from-pink-100 hover:to-rose-100 transition-all duration-300 group/link"
            >
              <div className="flex items-center space-x-3">
                <ExternalLink className="w-4 h-4 text-pink-400" />
                <span className="font-medium text-gray-700">{link.name}</span>
              </div>
              {link.price && (
                <span className="text-pink-500 font-semibold">{link.price}</span>
              )}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;