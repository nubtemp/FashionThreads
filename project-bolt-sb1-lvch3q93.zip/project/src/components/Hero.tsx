import React from 'react';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onShopClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onShopClick }) => {
  return (
    <section className="bg-gradient-to-br from-pink-100 via-rose-50 to-pink-50 py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-5xl lg:text-6xl font-bold text-gray-800 mb-6 font-playfair leading-tight">
              Revamp Your Wardrobe Today
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Discover the latest must-have styles and refresh your look with FashionThreads. Shop the trends now!
            </p>
            <button 
              onClick={onShopClick}
              className="bg-pink-400 hover:bg-pink-500 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center space-x-2"
            >
              <span>Shop Latest Trends</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
          <div className="order-1 lg:order-2">
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Woman styling clothes in wardrobe" 
                className="w-full h-96 lg:h-[500px] object-cover rounded-3xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-pink-200/20 to-transparent rounded-3xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero